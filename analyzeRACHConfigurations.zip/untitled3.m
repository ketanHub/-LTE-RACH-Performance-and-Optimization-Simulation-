% LTE RACH Simulation under Bursty Traffic
% Requires: LTE Toolbox, Communications Toolbox, Parallel Computing Toolbox

% Parameters
numUEs = 500;                      % Total UEs (bursty)
numPreambles = 64;                % Available preambles
burstTimeSlot = 100;              % Time slot when all UEs attempt access
backoffWindow = [10 20];          % Backoff range in ms
maxRetries = 5;

% PRACH Configuration
prach = ltePRACHConfig;
prach.PreambleFormat = 0;
prach.SeqGroup = 0;
prach.CyclicShiftIdx = 0;

% Simulation Results
success = zeros(numUEs,1);
delay = zeros(numUEs,1);
retransmissions = zeros(numUEs,1);

% Simulate all devices trying at the same time (bursty)
for ue = 1:numUEs
    attempt = 0;
    successFlag = false;
    backoffTotal = 0;
    
    while attempt < maxRetries && ~successFlag
        attempt = attempt + 1;
        
        % Random preamble selection
        preambleIdx = randi(numPreambles);

        % Check for collisions (simplified): detect duplicates
        if sum(rand(numUEs,1) < 1/numPreambles) == 1
            successFlag = true;
        else
            % Collision → wait random backoff
            backoff = randi(backoffWindow);
            backoffTotal = backoffTotal + backoff;
        end
    end
    
    success(ue) = successFlag;
    delay(ue) = burstTimeSlot + backoffTotal;
    retransmissions(ue) = attempt - 1;
end

% Results Summary
fprintf('Success Rate: %.2f%%\n', 100*mean(success));
fprintf('Average Delay: %.2f ms\n', mean(delay(success==1)));
fprintf('Avg Retransmissions: %.2f\n', mean(retransmissions));

% Plot
figure;
histogram(delay(success==1), 20);
title('Access Delay Distribution (Successful UEs)');
xlabel('Delay (ms)');
ylabel('Number of UEs');
