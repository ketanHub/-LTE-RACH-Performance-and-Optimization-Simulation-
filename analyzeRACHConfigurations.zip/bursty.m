% Combined RACH Performance and Optimization Simulation in LTE with Bursty Traffic
clc; clear; close all;

%% ========= General Parameters ========= %%
numDevicesSet = [0 50 100 200 400 600 800 1000]; % Device count sweep
defaultNumPreambles = 54;
defaultMaxRetrans = 1;
defaultBackoffWin = 10;
maxTimeSlots = 100;
burstyTraffic = true;  % 🔄 Enable bursty traffic

%% ========= Parameter Sweep Results (Code1 Style) ========= %%
successRates = zeros(size(numDevicesSet));
avgDelays = zeros(size(numDevicesSet));

for d = 1:length(numDevicesSet)
    numDevices = numDevicesSet(d);
    [succRate, avgDelay] = simulateRACH(numDevices, defaultNumPreambles, ...
        defaultMaxRetrans, defaultBackoffWin, maxTimeSlots, burstyTraffic);
    successRates(d) = succRate;
    avgDelays(d) = avgDelay;

    fprintf("Devices: %d | Success: %.2f%% | Avg Delay: %.2f slots\n", ...
        numDevices, 100 * succRate, avgDelay);
end

% Plotting
figure;
subplot(2,1,1);
plot(numDevicesSet, successRates * 100, '-o', 'LineWidth', 2);
xlabel('Number of Devices'); ylabel('Success Rate (%)');
title('Access Success Rate vs. Number of Devices'); grid on;

subplot(2,1,2);
plot(numDevicesSet, avgDelays, '-s', 'LineWidth', 2, 'Color', [0.8500 0.3250 0.0980]);
xlabel('Number of Devices'); ylabel('Avg Access Delay (slots)');
title('Access Delay vs. Number of Devices'); grid on;


%% ========= Parameter Optimization (Code2 Style) ========= %%
numDevices = 1000;
numPreamblesSet = [32, 64, 128];
backoffSet = [5, 10, 20];
retransmissionSet = [3, 5, 7];
results = [];

for np = numPreamblesSet
    for bw = backoffSet
        for rt = retransmissionSet
            [succRate, avgDelay, collisions] = simulateRACH(numDevices, np, rt, bw, maxTimeSlots, burstyTraffic);
            results = [results; np, bw, rt, succRate, avgDelay, collisions];
        end
    end
end

% Store in table
T = array2table(results, 'VariableNames', ...
    {'Preambles','BackoffWin','MaxRetrans','SuccessRate','AvgDelay','Collisions'});

disp("=== RACH Optimization Results ===");
disp(T);

% Find Optimal
[~, idx] = max(T.SuccessRate);
optimalConfig = T(idx,:);
fprintf('\n🎯 Optimal RACH Configuration under Heavy Load:\n');
disp(optimalConfig);

% Heatmaps
figure;
for i = 1:length(retransmissionSet)
    rt = retransmissionSet(i);
    subplot(1, length(retransmissionSet), i);

    subT = T(T.MaxRetrans == rt, :);
    Z = nan(length(numPreamblesSet), length(backoffSet));

    for j = 1:height(subT)
        row = find(numPreamblesSet == subT.Preambles(j), 1);
        col = find(backoffSet == subT.BackoffWin(j), 1);
        if ~isempty(row) && ~isempty(col)
            Z(row, col) = subT.SuccessRate(j) * 100;
        end
    end

    % Create heatmap with proper labels and title
    h = heatmap(string(backoffSet), string(numPreamblesSet), Z, ...
        'Colormap', parula);

    h.Title = sprintf('Success Rate (%%) | Retrans: %d', rt);
    h.XLabel = 'Backoff Window';
    h.YLabel = 'Num of Preambles';
end


%% ========= RACH Simulation Function ========= %%
function [successRate, avgDelay, collisions] = simulateRACH(numDevices, numPreambles, ...
    maxRetransmissions, backoffWindow, maxTimeSlots, burstyTraffic)

    accessSuccess = zeros(numDevices, 1); % 0 = not attempted, 1 = success, -1 = failed
    retransmissions = zeros(numDevices, 1);
    backoffTimers = zeros(numDevices, 1);
    accessDelay = zeros(numDevices, 1);
    collisions = 0;

    % 🔄 Bursty traffic: each device activates at a random time
    if burstyTraffic
        activationTimes = randi([1, floor(maxTimeSlots / 2)], numDevices, 1);
    else
        activationTimes = zeros(numDevices, 1);
    end

    for t = 1:maxTimeSlots
        % 🔍 Eligible devices: not done, not backing off, activated
        eligibleUEs = find((accessSuccess == 0) & (backoffTimers == 0) & (activationTimes <= t));
        numEligible = length(eligibleUEs);

        if numEligible == 0
            backoffTimers(backoffTimers > 0) = backoffTimers(backoffTimers > 0) - 1;
            continue;
        end

        preambles = randi(numPreambles, numEligible, 1);
        [~, ~, idx] = unique(preambles);
        counts = histc(idx, 1:numel(unique(preambles)));

        for i = 1:numEligible
            ue = eligibleUEs(i);
            if counts(idx(i)) == 1
                accessSuccess(ue) = 1;
                accessDelay(ue) = t;
            else
                collisions = collisions + 1;
                retransmissions(ue) = retransmissions(ue) + 1;
                if retransmissions(ue) <= maxRetransmissions
                    backoffTimers(ue) = randi(backoffWindow);
                else
                    accessSuccess(ue) = -1;
                end
            end
        end
        backoffTimers(backoffTimers > 0) = backoffTimers(backoffTimers > 0) - 1;
    end

    numSuccess = sum(accessSuccess == 1);
    successRate = numSuccess / numDevices;
    if numSuccess > 0
        avgDelay = mean(accessDelay(accessSuccess == 1));
    else
        avgDelay = NaN;
    end
end