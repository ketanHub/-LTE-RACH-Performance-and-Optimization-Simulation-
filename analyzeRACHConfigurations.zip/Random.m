%% RACH Performance Simulation Script
% Author: Your Name
% Date: [Add Date]

%% ========== PHASE 1: Initialization ==========
deviceCounts = [50, 100, 300, 500, 1000];
numPreambles = 64;
trafficPattern = 'random';  % Options: 'periodic', 'bursty', 'random'

successRates = zeros(size(deviceCounts));
avgDelays = zeros(size(deviceCounts));

%% ========== PHASE 2: RACH Simulation ==========
for i = 1:length(deviceCounts)
    numDevices = deviceCounts(i);

    % Each device randomly selects a preamble
    preambles = randi(numPreambles, 1, numDevices);

    % Identify collisions
    preambleUsage = histcounts(preambles, 1:numPreambles+1);
    collisions = preambleUsage(preambles) > 1;

    % Success = devices with unique preamble
    successRates(i) = sum(~collisions) / numDevices;

    % Simulated random access delay between 10 and 50 ms
    avgDelays(i) = mean(randi([10, 50], 1, numDevices));
end

%% ========== PHASE 3: Display Results ==========
fprintf('Number of Devices\tSuccess Rate\tAverage Delay (ms)\n');
for i = 1:length(deviceCounts)
    fprintf('%d\t\t\t%.2f\t\t%.2f\n', deviceCounts(i), successRates(i), avgDelays(i));
end

%% ========== PHASE 4: Plot Results ==========
figure;
plot(deviceCounts, successRates, '-o', 'LineWidth', 2);
title('Access Success Rate vs Number of Devices');
xlabel('Number of Devices');
ylabel('Success Rate');
grid on;

figure;
plot(deviceCounts, avgDelays, '-o', 'LineWidth', 2);
title('Average Access Delay vs Number of Devices');
xlabel('Number of Devices');
ylabel('Average Delay (ms)');
grid on;
